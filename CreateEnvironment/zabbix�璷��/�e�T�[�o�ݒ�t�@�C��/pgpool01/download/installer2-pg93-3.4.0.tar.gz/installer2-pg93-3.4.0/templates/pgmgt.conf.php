<?php
define('_PGPOOL2_LANG', 'en');
define('_PGPOOL2_VERSION', '3.3');
define('_PGPOOL2_CONFIG_FILE', '/home/anzai/local/pgpool/etc/pgpool.conf');
define('_PGPOOL2_PASSWORD_FILE', '/home/anzai/local/pgpool/etc/pcp.conf');
define('_PGPOOL2_COMMAND', '/home/anzai/local/pgpool/bin/pgpool');
define('_PGPOOL2_CMD_OPTION_C', '0');
define('_PGPOOL2_CMD_OPTION_LARGE_D', '0');
define('_PGPOOL2_CMD_OPTION_D', '0');
define('_PGPOOL2_CMD_OPTION_M', 's');
define('_PGPOOL2_CMD_OPTION_N', '0');
define('_PGPOOL2_CMD_OPTION_LARGE_C', '0');
define('_PGPOOL2_LOG_FILE', '/tmp/pgpool.log');
define('_PGPOOL2_PCP_DIR', '/home/anzai/local/pgpool/bin');
define('_PGPOOL2_PCP_HOSTNAME', 'localhost');
define('_PGPOOL2_STATUS_REFRESH_TIME', '0');
?>
